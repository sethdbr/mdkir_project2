from fitting_functions import *

print(linear(2,3,4))
print(slope_units('meters','kg'))
print_equation(4,1,'meters','kg')
